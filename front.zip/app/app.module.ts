import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { UserDataComponent } from './user-data/user-data.component'
import { SearchDeleteComponent } from './search-delete/search-delete.component';

import { UserRegistrationService } from './user-registration.service';
import { HttpClientModule } from '@angular/common/http';
import {AuthenticationService} from './authentication.service';
import {AlertService} from './alert.service';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UpdateComponent } from './update/update.component';
import { NgxPaginationModule } from "ngx-pagination";
import { UserDetailsComponent } from './user-details/user-details.component';
@NgModule({
  declarations: [
    AppComponent,
    UserDataComponent,
    SearchDeleteComponent,
    LoginComponent,
    HomeComponent,
    UpdateComponent,
    UserDetailsComponent,
    ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgxPaginationModule
    ],
  providers: [UserRegistrationService, 
                AlertService,
             AuthenticationService
            ],
  bootstrap: [AppComponent]
})
export class AppModule { }
