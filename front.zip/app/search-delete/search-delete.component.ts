import { Component, OnInit } from '@angular/core';
import { UserRegistrationService } from '../user-registration.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from './../user';
import {UserDetailsComponent  } from '../user-details/user-details.component';
import { Observable } from "rxjs";



@Component({
  selector: 'app-search-delete',
  templateUrl: './search-delete.component.html',
  styleUrls: ['./search-delete.component.css']
})
export class SearchDeleteComponent implements OnInit {

  users:any=[];
  
  constructor(private service:UserRegistrationService,private route: ActivatedRoute,private router: Router) { }

  ngOnInit() {
    let resp=this.service.getUsers();
   resp.subscribe((data)=>this.users=data);
  }

  reloadData() {
    this.users = this.service.getUsers();
  }

  
  public delteUser(id:number){
    let resp= this.service.deleteUser(id);
    resp.subscribe((data)=>{
      return this.users = data;
    });
   }


   updateUser(id: number){
    this.router.navigate(['update', id]);
  }
userDetails(id: number){
    this.router.navigate(['details', id]);
  }
}

