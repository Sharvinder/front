import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../user';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  id: number;
 
  user: any=[];

  constructor(private route: ActivatedRoute,private router: Router,
    private service: UserRegistrationService) { }

  

 
  ngOnInit() {

    
    this.user = new User();

    this.id = this.route.snapshot.params['id'];
    
    let resp=this.service.getUsers();
    resp.subscribe((data)=>this.user=data);
    this.service.getUserById(this.id)
    .subscribe(data => {
      console.log(data)
      this.user = data;
    }, error => console.log(error));
}

  
updateUser() {
    this.service.updateUser(this.id,this.user)
      .subscribe(data => {
        console.log(data), 
        this.user = new User();

    this.gotoList();
  }, error => console.log(error));
}

  onSubmit() {
    this.updateUser();    
  }

  gotoList() {
    this.router.navigate(['/search']);
  }
}

  

  

