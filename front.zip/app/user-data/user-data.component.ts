import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../user';
import { UserRegistrationService } from '../user-registration.service';
import {  Router } from '@angular/router';





@Component({
  selector: 'app-user-data',
  templateUrl: './user-data.component.html',
  styleUrls: ['./user-data.component.css']
})
export class UserDataComponent implements OnInit {

  

  user: User= new User();
  message:any;
  registerForm: FormGroup;
  submitted: boolean;


  constructor(private formBuilder: FormBuilder,private service:UserRegistrationService
    ,private router:Router) { }

   
  
  ngOnInit(){

    this.registerForm = this.formBuilder.group({
      name: ['', Validators.required],
      phoneno:['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      salary: ['', Validators.required],
      dob: ['', [Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]],

      
      
    });
  }
  get f() 
  {
    
    return this.registerForm.controls; 
  }

  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }

 
  save() {
    this.service
    .doRegistration(this.user).subscribe(data => {
      console.log(data)
      this.user = new User();
      this.gotoList();
    }, 
    error => console.log(error));
  }
  
public registerNow(){
  this.submitted=true;
    
    this.save();
      }

      keyPressNumbersDecimal(event) {
        var charCode = (event.which) ? event.which : event.keyCode;
        if (charCode != 46 && charCode > 31
          && (charCode < 48 || charCode > 57)
          && (charCode>90 || charCode==188)) {
          event.preventDefault();
          return false;
        }
        return true;
      }
      gotoList() {
        this.router.navigate(['/search']);
      }
}
  
    
    