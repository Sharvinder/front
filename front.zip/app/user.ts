export class User{
    
     name:string;
     phoneno:string;
     email:string;
     salary:string;
    dob:string
}