import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  constructor(private http:HttpClient) { }


  public doRegistration(user:Object){
    let username='javatechie'
    let password='jt143'
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    return this.http.post("http://localhost:8090/data/register",user,{headers,responseType: 'text'});
  }
  public getUsers(){
    let username='javatechie'
    let password='jt143'
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    return this.http.get("http://localhost:8090/data/getAllUsers",{headers});
  }

  
public getUserById(id:number){
  
  let username='javatechie'
  let password='jt143'
  const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
  return this.http.get("http://localhost:8090/data/form"+id,{headers});
  
}
  public deleteUser(id) {
    let username='javatechie'
    let password='jt143'
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    return this.http.delete("http://localhost:8090/data/cancel/"+id,{headers});
  }
  public updateUser(id: number, value: any){
    let username='javatechie'
    let password='jt143'
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    return this.http.put("http://localhost:8090/data/form/"+id,value,{headers,responseType: 'text'});
  }

}


